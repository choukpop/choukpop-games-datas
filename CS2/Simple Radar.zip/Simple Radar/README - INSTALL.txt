---------------------------------

Hello there!

AREDONE here with a quick guide on how too install. I hope you'll enjoy Simple Radar.

---------------------------------

HOW TO INSTALL

1) Make sure CS:GO is closed
2) Go to C:\YOUR DIRECTORY\Steam\steamapps\common\Counter-Strike Global Offensive\csgo\resource\
3) Make a copy of the entire overviews folder and save it on your desktop (as a backup)
4) Now go back to the Simple Radar folder, open "01 default" and select and copy all files  inside 
5) Then open overviews (C:\YOUR DIRECTORY\Steam\steamapps\common\Counter-Strike Global Offensive\csgo\resource\overviews) and paste all the new Simple Radar .dds files, restart game and you are ready to rock!
6) For best results play with resolutions that have a height of 1024 or greater.

If you also want Simple Radar to show up in spectate (GOTV, BIGMAP), you just have to copy all the files from the "02 spectate" folder into the overviews folder similar to step 5.

Now that you're done, come hang out with the rest of the community of people that love the game as much as you and me ;)

https://discord.gg/vkYqFnR 

---------------------------------

HOW TO REMOVE

Don't like how Simple Radar looks in action? You can revert back using the backup you made in step 2 or by verifying integrity of game cache on steam.

---------------------------------

OPTIMAL RADAR SETTINGS

cl_radar_scale 0.5 or higher
cl_radar_rotate 1 but works with 0 too
cl_radar_always_centered 1 or 0 - doesn't matter
cl_radar_icon_scale_min 0.4

cl_hud_radar_scale 1.1 / 1.2 / 1.3 could help aswell 

---------------------------------